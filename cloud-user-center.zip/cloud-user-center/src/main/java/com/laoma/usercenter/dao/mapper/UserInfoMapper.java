package com.laoma.usercenter.dao.mapper;

import com.laoma.usercenter.common.mapper.BaseMapper;
import com.laoma.usercenter.dao.entity.UserInfo;

public interface UserInfoMapper extends BaseMapper<UserInfo> {
}