package com.laoma.usercenter.common.entity;

/**
 * @program: lmwbms
 * @description: 所有数据库model类的基类
 * @author: 老马
 * @create: 2021-03-01 10:33
 **/
public class BaseEntity {
}
